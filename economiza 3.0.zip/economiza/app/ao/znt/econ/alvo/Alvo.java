package ao.znt.econ.alvo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Entity;

import play.data.validation.Min;
import play.data.validation.Required;
import play.db.jpa.Model;

@Entity
public class Alvo extends Model{
	@Required
	public String descricao;
	public String prazo;//longo curto medio prazo
	public Calendar dataInico;
	public Calendar dataFim;
	@Required
	@Min(100)
	public double valorNecessario;
	public double valorHaPoupar;
	public int periudo;
	
	public static double saldo = 0;/***///valor sobrando depois de definir os orcamentos obrigatorio
	public static int duracao; //periodo q levará até juntar o valor necessário
	//anotar pra noa ir no db
	public static Alvo alvo;
	public static double percentagem ;
	

	
	public static List<Alvo> avaliar(Alvo alvo,double limite) {
		List<Alvo> alvos = new ArrayList<Alvo>();
		saldo = limite;
		//formular tres 3 sujestoes a curto-medio-longo prazo
		
		Alvo a2 = curtoPrazo(alvo);
		alvos.add(a2);
		
		Alvo a3 = medioPrazo(alvo);
		alvos.add(a3);
		
		Alvo a1 = longoPrazo(alvo);
		alvos.add(a1);
		
		return alvos;
	}


	private static Alvo longoPrazo(Alvo alvo) {
		
        percentagem = 0.25;
		
	    
	    return alvoFactory(percentagem,alvo,"longo");
	}
	
	private static Alvo medioPrazo(Alvo alvo) {
        percentagem = 0.45;
		
		
	    return alvoFactory(percentagem,alvo,"medio");
	}

	private static Alvo curtoPrazo(Alvo alvo) {
		 percentagem = 0.60;
		
		return alvoFactory(percentagem,alvo,"curto");
		
	} 
	
	public static Alvo alvoFactory(double percentagem,Alvo alvo,String prazo) {
		Alvo alvoAtivo = new Alvo();
		double vNecessario = alvo.valorNecessario;/***/
		double vPoupar =  percentagem*saldo;
		Calendar inicio = Calendar.getInstance();/***/
		Calendar fim = Calendar.getInstance();
		

		duracao = (int) (vNecessario/vPoupar);
	    inicio.add(Calendar.MONTH, duracao);
	    fim.setTimeInMillis(inicio.getTimeInMillis());
	    
	    
	    alvoAtivo.dataFim = fim;
	    alvoAtivo.dataInico = Calendar.getInstance();
	    alvoAtivo.valorHaPoupar = vPoupar;
	    alvoAtivo.descricao = alvo.descricao;
	    alvoAtivo.valorNecessario = alvo.valorNecessario;
	    alvoAtivo.periudo = duracao;
	    alvoAtivo.prazo = prazo;
		
	    return alvoAtivo;
	}

}
