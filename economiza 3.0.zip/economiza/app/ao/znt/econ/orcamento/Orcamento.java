package ao.znt.econ.orcamento;




import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import ao.znt.econ.compra.Compra;
import ao.znt.econ.exception.DataException;
import ao.znt.econ.exception.NegativeException;
import ao.znt.econ.exception.SaldoException;
import play.data.validation.Min;
import play.data.validation.Required;
import play.db.jpa.Model;

@Entity
public class Orcamento extends Model {
	@Required
	@Min(1000)
	public double saldo;
	@Required
	public Calendar dataDoOrcamento;
	@Required
    public String categoria;
    @OneToMany
    @JoinColumn(name="idOrcamento")
    public List<Compra> compras;
    //buscar orsamento atravez do mes e da categoria
	
    public Orcamento(Calendar data,double saldo) {
    	this.dataDoOrcamento = data;
    	this.saldo = saldo;
    	
    	
    }
    
	public void gastar(Compra compra) throws SaldoException {
		if(compra.getValor()>saldo) {
			throw new SaldoException("Saldo insuficiente");
		}else this.saldo -= compra.getValor();
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	public String getCategoria() {
		return this.categoria;
	}

	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public Calendar getDataDoOrcamento() {
		return dataDoOrcamento;
	}

	public void depositar(double valor) throws NegativeException{
		if (valor < 0) {
			throw new NegativeException("tentou depositar um valor negativo");
			} else {
			this.saldo += valor;
			}
		
	}
	

	public static List<Orcamento> findAtualOrc(List<Orcamento> orcs){
		List<Orcamento> orcamentos = new ArrayList<Orcamento>();
		Calendar dataAtual = Calendar.getInstance();
		for (Orcamento orcamento : orcs) {
			if(orcamento.getDataDoOrcamento().get(Calendar.MONTH) == dataAtual.get(Calendar.MONTH)&&
			   orcamento.getDataDoOrcamento().get(Calendar.YEAR) == dataAtual.get(Calendar.YEAR)) {
				orcamentos.add(orcamento);
			}
		}
		return orcamentos;
	}

	public static void existeOrc(Orcamento orc,List<Orcamento> orcamentos) throws DataException{
		List<Orcamento> orcs = orcamentos;
	
		for (Orcamento orcamento : orcs) {
			if(orcamento.getDataDoOrcamento().get(Calendar.MONTH) == orc.getDataDoOrcamento().get(Calendar.MONTH)&&
			   orcamento.getDataDoOrcamento().get(Calendar.YEAR) == orc.getDataDoOrcamento().get(Calendar.YEAR)&&
			   orcamento.getCategoria().equals(orc.getCategoria())) {
				
						throw new DataException("Já existe orcamento para esta data: ");
		}
      }
	
	}

	
}
