package ao.znt.econ.sistema;

import java.util.Calendar;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		double b = 1.9;
		
		
		
		int i1 = (int) Math.round(b);
		
		System.out.println(i1);
	}

}
