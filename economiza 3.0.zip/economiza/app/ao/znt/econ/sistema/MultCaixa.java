package ao.znt.econ.sistema;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import ao.znt.econ.compra.Compra;
import ao.znt.econ.exception.DataException;
import ao.znt.econ.exception.SaldoException;
import ao.znt.econ.orcamento.Orcamento;

public class MultCaixa {

	private Orcamento orcamento;
	private Compra compra;


	public MultCaixa(Compra compra,Orcamento orc) {
		this.compra = compra;
		this.orcamento = orc;
	}
	
	public double pagar() throws DataException, SaldoException{
		
		if(orcamento!=null) {
			orcamento.gastar(compra);
			
		}else {
			throw new DataException("Não definiste orcamento para este mes");
		}
		
		return orcamento.getSaldo();
	}
	
	
	//METODOS ESPECIAS OU MERCENARIOS

}