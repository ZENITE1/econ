package ao.znt.econ.compra;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;

import groovyjarjarpicocli.CommandLine.Mixin;
import play.data.validation.Min;
import play.data.validation.MinSize;
import play.data.validation.Required;
import play.db.jpa.Model;
@Entity
public class Compra extends Model{

	@MinSize(3)
	@Required
	public String descricao;
	@Required
	@Min(5)
	public double valor;
	@Required
	public String categoria;
	@Required
	public Calendar dataDaCompra;

	public Compra(String desc, double valor) {
		this.descricao = desc;
		this.valor = valor;
		this.dataDaCompra = Calendar.getInstance();
		
	}

	public double getValor() {
		return this.valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public Calendar getData() {
		return dataDaCompra;
	}

	public void setData(Calendar data) {
		this.dataDaCompra = data;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

}
