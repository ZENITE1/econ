package ao.znt.econ.exception;

public class DataException extends Exception{

	public DataException(String msg) {
		super(msg);
	}

}
