package ao.znt.econ.exception;

public class SaldoException extends Exception{

	public SaldoException(String msg) {
		super(msg);
	}

}
