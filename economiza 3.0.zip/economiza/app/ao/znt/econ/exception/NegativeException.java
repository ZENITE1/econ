package ao.znt.econ.exception;

public class NegativeException extends Exception{

	public NegativeException(String msg) {
		super(msg);
	}

}
