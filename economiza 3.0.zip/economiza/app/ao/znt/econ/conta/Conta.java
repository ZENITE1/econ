package ao.znt.econ.conta;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import ao.znt.econ.alvo.Alvo;
import ao.znt.econ.exception.SaldoException;
import models.Usuario;
import play.data.validation.Min;
import play.data.validation.Required;
import play.db.jpa.Model;

@Entity
public class Conta extends Model{

	@Required
	@Min(1000)
	public double saldo;
	public double saldoDisponivel;
	@Required
	@Min(2000)
	public double limite;
	public double limiteDisponivel;
	public double pontero;
	
	
	
	public void depositar(double valor) {
		saldo+=valor;
		
	}
	public void alteraLimite(double limite) throws SaldoException {
		if(limite>=this.saldo) {
			throw new SaldoException("O limite não pode ser superior ou igual ao saldo");
			}else if(limite<2000) {
			throw new SaldoException("O limite não pode ser inferior a 2000 Kz");
			}
		this.limite = limite;
	}
	public void sacar(double valor) throws SaldoException {
		if(valor>getSaldoDisponivel()) {
			throw new SaldoException("Estás a exceder o valor limite, o saldo disponivel é de: "+getSaldoDisponivel());
		}
		saldo = saldo-valor;
		
	}
	
	public double getSaldoDisponivel() {
		saldoDisponivel = saldo-limite;
		return saldoDisponivel;
	}
	public double getLimiteDisponivel() {
		limiteDisponivel = limite - pontero;
		return limiteDisponivel;
	}
	public void avaliarLimite(Alvo alvo) throws SaldoException {
		System.out.println("Estado do pontero: "+pontero);
		if(limiteDisponivel <= 0) {
			throw new SaldoException("Não terá saldo para fazer essa popança");
		}
		pontero = pontero + alvo.valorHaPoupar;
		System.out.println("Estado do pontero 1: "+pontero);
	}
	
	

}
