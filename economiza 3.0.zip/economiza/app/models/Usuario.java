package models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import ao.znt.econ.alvo.Alvo;
import ao.znt.econ.conta.Conta;
import ao.znt.econ.orcamento.Orcamento;
import play.data.validation.Email;
import play.data.validation.Equals;
import play.data.validation.Password;
import play.data.validation.Required;
import play.db.jpa.Model;
import play.libs.Crypto;

@Entity
public class Usuario extends Model{
	@Required
	public String nome;
	@Required
	@Email
	public String email;
	@Required
	@Password
	public String senha;
	@Equals("senha")
	public String confirmaSenha;
	
	
	@OneToOne
	@JoinColumn(name="idConta")
	public Conta conta;
	@OneToMany
    @JoinColumn(name="idUsuario")
	public List<Orcamento> orcamentos;
	@OneToMany
    @JoinColumn(name="idUsuario")
	public List<Alvo> alvos;
	
	
	public void setSenha(String senha) {
		this.senha = Crypto.passwordHash(senha);
	}
	public void setConfirmaSenha(String confirmaSenha) {
		this.confirmaSenha = Crypto.passwordHash(confirmaSenha);
	}

}
