package controllers;

import java.util.List;

import ao.znt.econ.alvo.Alvo;
import ao.znt.econ.conta.Conta;
import ao.znt.econ.exception.SaldoException;
import models.Usuario;
import play.data.validation.Valid;
import play.mvc.Controller;
import play.mvc.With;

@With(Seguranca.class)
public class Alvos extends Controller {
	
	public static void form() {
		Alvo alvo = new Alvo();
		render(alvo);

	}
	
	public static void avaliar(@Valid Alvo alvo) {
		if(validation.hasErrors()) {
			validation.keep();
			form();
		}
		//pegar a conta do user e passar o limite pra calcular o alvo
		Conta conta = getUsuario().conta;
		
		List<Alvo> sujestoesAlvos = Alvo.avaliar(alvo,conta.limiteDisponivel);
		mostra(sujestoesAlvos);
	}
	public static void mostra(List<Alvo> sujestoes) {
		//usa o form para mostrar as sujestoes
		session.put("alvos.sujesoes", sujestoes);
		render(sujestoes);
	}
	public static void guardar(Alvo alvo) {
		Conta conta = getUsuario().conta;
		
		try {
			conta.avaliarLimite(alvo);
		} catch (SaldoException e) {
			flash.error(e.getMessage());
			form();//é pra retornar em mostra(jujestoes);
		}
		
		Usuario usuario = getUsuario();
		
		usuario.alvos.add(alvo);
		alvo.save();
		conta.save();
		flash.success("Alvo Adicionado");
		
	     listar();
	}
	public static Usuario getUsuario() {
		return Usuario.findById(Long.parseLong(session.get("usuario.id")));
	}
	public static void listar() {
		List<Alvo> alvos = getUsuario().alvos;
		render(alvos);
	}
	public static void deleta(Long id) {
		Alvo alvo = Alvo.findById(id);
		alvo.delete();
		
		listar();
	}

}
