package controllers;

import play.mvc.Controller;
import play.mvc.With;

@With(Seguranca.class)
public class Dicas extends Controller{

	public static void page() {
		render();
	}
}
