package controllers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import ao.znt.econ.compra.Compra;
import ao.znt.econ.conta.Conta;
import ao.znt.econ.exception.DataException;
import ao.znt.econ.exception.SaldoException;
import ao.znt.econ.orcamento.Orcamento;
import models.Usuario;
import play.data.validation.Valid;
import play.data.validation.Validation;
import play.mvc.Controller;
import play.mvc.With;
import play.mvc.Scope.Flash;

@With(Seguranca.class)
public class Orcamentos extends Controller{
	
	public static void form() {
		Orcamento orc = new Orcamento(null, 0);
		render(orc);
	}
	public static void salvar(@Valid Orcamento orcamento){
		
		Usuario usuario = Usuario.findById(Long.parseLong(session.get("usuario.id")));
	    Conta conta = usuario.conta; 
		
		if(validation.hasErrors()) {
			validation.keep();
			form();
		}
	    
	    	try {
			
			
			 
			Orcamento.existeOrc(orcamento,getOrcs());
			
			conta.sacar(orcamento.saldo);
			
			usuario.orcamentos.add(orcamento);
			orcamento.save();
			conta.save();
			flash.success("Orcamento Definido com sucesso");
			form();
			
		} catch (SaldoException e) {
			//Verificar se o saldo disponivel é suficiente
			flash.error(e.getMessage());
			form();
		} catch (DataException e) {
			//Verificar se já existe um orc com a mesma data e a mesma categoria
			flash.error("Já existe orcamento para esta data");
			form();
		} 
		
	}
	public static void listar() {
	
		List<Orcamento> lista = getOrcs();
		render(lista);
	}
	public static void deletar(long id) {
		Orcamento orc = Orcamento.findById(id);
		orc.delete();
		listar();
		
	}
	public static void mostra(long id) {
		Orcamento orcamento = Orcamento.findById(id);
		
		render(orcamento);
	}
	public static List<Orcamento> getOrcs(){
		
        Usuario usuario = Usuario.findById(Long.parseLong(session.get("usuario.id")));
    
        return usuario.orcamentos;
	
		 
	}
	
	//METODOS ESPECIAS
	
//	public static void existeOrc(Orcamento orc) throws DataException{
//		List<Orcamento> orcs = Orcamento.findAll();
//		for (Orcamento orcamento : orcs) {
//			if(orcamento.getDataDoOrcamento().get(Calendar.MONTH) == orc.getDataDoOrcamento().get(Calendar.MONTH)&&
//			   orcamento.getDataDoOrcamento().get(Calendar.YEAR) == orc.getDataDoOrcamento().get(Calendar.YEAR)&&
//			   orcamento.getCategoria().equals(orc.getCategoria())) {
//				
//						throw new DataException("Já existe orcamento para esta data: ");
//		}
//		   }
//	
//		
//	}

}
