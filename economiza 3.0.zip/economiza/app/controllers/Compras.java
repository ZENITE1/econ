package controllers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.hibernate.mapping.Component.ValueGenerationPlan;

import ao.znt.econ.compra.Compra;
import ao.znt.econ.exception.DataException;
import ao.znt.econ.exception.SaldoException;
import ao.znt.econ.orcamento.Orcamento;
import ao.znt.econ.sistema.MultCaixa;
import models.Usuario;
import play.data.validation.Validation;
import play.modules.paginate.ValuePaginator;
import play.mvc.Controller;
import play.mvc.With;

@With(Seguranca.class)
public class Compras extends Controller{
	
	

	public static void form() {
		Compra compra = new Compra(null, 0);
		//depois reduzir os orcs so para o mes corrente
		 Usuario usuario = Usuario.findById(Long.parseLong(session.get("usuario.id")));
		 List<Orcamento> lista = usuario.orcamentos;
			
		List<Orcamento> orcamentos = Orcamento.findAtualOrc(lista);
		render(compra,orcamentos);
	}
	

	public static void listar() {
		List<Compra> lista1 = new ArrayList<Compra>();
        Usuario usuario = Usuario.findById(Long.parseLong(session.get("usuario.id")));
    
		List<Orcamento> lista = usuario.orcamentos;
		for (Orcamento orcamento : lista) {
			lista1.addAll(orcamento.compras);
		}
		
		
		ValuePaginator listaPaginada = new ValuePaginator(lista1);
		listaPaginada.setPageSize(3);
		
		render(listaPaginada);
	}
	public static void mostra(Long id) {
		Compra compra = Compra.findById(id);
		render(compra);
	}
	
	public static void compra(Compra compra,Long idOrcamento) {
	
	       validar(compra,idOrcamento);
	}
	
	
	
	
	//METODO ESPECIAS

	public static void validar(Compra compra,Long idOrcamento) {
		Orcamento orc = null;
		try {
			
		orc = Orcamento.findById(idOrcamento);
		
		}catch (IllegalArgumentException e) {
			flash.error("Primeiro defina os orcçamentos");
			Orcamentos.form();
		}
		String categoria = orc.getCategoria();
		
		if(categoria.equals("ALIMENTO")) {
			compra.setCategoria("ALIMENTO"); 
		}else if (categoria.equals("ROUPA")) {
			compra.setCategoria("ROUPA"); 
		}else if (categoria.equals("LAZER")) {
			compra.setCategoria("LAZER"); 
		}
		compra.setData(Calendar.getInstance());
		
		validation.valid(compra);
		
		if(validation.hasErrors()) {
			validation.keep();
			form();
		}
		
		pagar(compra,idOrcamento);
	}
	
	public static void pagar(Compra compra, Long idOrcamento) {
	 Orcamento orc = Orcamento.findById(idOrcamento);
		
      MultCaixa caixa = new MultCaixa(compra, orc);
		
		try {
		  double saldo = caixa.pagar();
		  orc.setSaldo(saldo);
		  orc.save();
		  
		} catch (DataException e) {
			flash.error("Não definiste orcamento para este mes: ");
			form();
		} catch (SaldoException e) {
			flash.error("Saldo insuficiente. Está com :"+orc.getSaldo());
			form();
		}
		
		orc.compras.add(compra);
		compra.save();
		flash.success("Compra adicionada na lista");
		listar();
	}
	


	
}
