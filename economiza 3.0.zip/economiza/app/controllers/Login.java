package controllers;

import models.Usuario;
import play.data.validation.Valid;
import play.libs.Crypto;
import play.mvc.Controller;

public class Login extends Controller{

	
	public static void form() {
		Usuario usuario = new Usuario();
		render(usuario);
	
	}
	public static void logar(Usuario usuario) {

		
		Usuario u = Usuario.find("email = ?1 and senha = ?2",
				usuario.email, usuario.senha).first();
		if(u == null) {
			form();
		}else {
			session.put("usuario.nome", u.nome);
			session.put("usuario.email", u.email);
			session.put("usuario.id", u.id);
			
			Home.home();
		}
	}
	public static void sair() {
		session.clear();
		form();
	}
}
