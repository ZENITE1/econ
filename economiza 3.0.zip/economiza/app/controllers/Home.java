package controllers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import ao.znt.econ.compra.Compra;
import ao.znt.econ.orcamento.Orcamento;
import models.Usuario;
import play.mvc.Controller;
import play.mvc.With;

@With(Seguranca.class)
public class Home extends Controller{
	
	public static void home() {
		//passar o valor somando o preco ds compras
		double alimento = 0,roupa = 0,lazer = 0;
		List<Compra> compras = new ArrayList<Compra>();
		List<Orcamento> orcamentos = getUsuario().orcamentos;
		List<Orcamento> orcamentosActual = Orcamento.findAtualOrc(orcamentos);

		for (Orcamento orcamento : orcamentosActual) {
			compras.addAll(orcamento.compras);
		}
		for (Compra compra : compras) {
			if(compra.categoria.equals("ALIMENTO"))
				alimento = alimento + compra.valor;
			else if(compra.categoria.equals("ROUPA"))
				roupa = roupa + compra.valor;
			else if(compra.categoria.equals("LAZER"))
				lazer = lazer + compra.valor;
		
		}
		
		render(alimento,roupa,lazer);
	}
	public static Usuario getUsuario() {
		return Usuario.findById(Long.parseLong(session.get("usuario.id")));
	}

}
