package controllers;

import ao.znt.econ.conta.Conta;
import models.Usuario;
import play.data.validation.Valid;
import play.libs.Crypto;
import play.mvc.Controller;

public class Cadastro extends Controller {
	
	public static void form() {
		Conta conta = new Conta();
		Usuario usuario = new Usuario();
		render(usuario,conta);
	}
	
	public static void guardar(@Valid Usuario usuario,@Valid Conta conta) {
		
			System.out.println("Senha: "+usuario.senha);
			System.out.println("Confimação da Senha: "+usuario.confirmaSenha);
			
		
		if(validation.hasErrors()) {
			validation.keep();
			form();
			
		}
		usuario.conta = conta;
		conta.save();
		usuario.save();
		System.out.println("Cadastro:"+ usuario.senha);
		flash.success("Usuario cadastrado com sucesso");
		Login.form();
		
		}/*else if(validation.equals(usuario.senha, Crypto.passwordHash(usuario.confirmaSenha))) { {
			flash.error("A password não é compativel com a comfimação");
			form();
		}*/
	

}
