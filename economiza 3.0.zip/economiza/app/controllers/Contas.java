package controllers;

import ao.znt.econ.conta.Conta;
import ao.znt.econ.exception.SaldoException;
import models.Usuario;
import net.sf.ehcache.statistics.FlatStatistics;
import play.mvc.Before;
import play.mvc.Controller;
import play.mvc.With;

@With(Seguranca.class)
public class Contas extends Controller{
	
	
	
	public static void mostra() {
		//buscar conta com id do usuario
		Usuario usuario = getUsuario();
		Conta conta = getConta();
		render(conta,usuario);
	}
	public static void depositar(Conta conta) {
		Conta contaCorrente = getConta();
		contaCorrente.depositar(conta.saldo);
		contaCorrente.save();
		flash.success(conta.saldo+" Kz depositado");
		mostra();
		
	}
	public static void definirLimite(Conta conta) {
		
		Conta contaCorrente = getConta();
		try {
			contaCorrente.alteraLimite(conta.limite);
		} catch (SaldoException e) {
			
			flash.error(e.getMessage());
			mostra();
		}
		contaCorrente.save();
		flash.success("Limiti Alterado para "+conta.limite+" Kz");
		mostra();
	}
	
	public static Conta getConta() {
		Usuario usuario = getUsuario();
		return usuario.conta;
	}
	public static Usuario getUsuario() {
		return Usuario.findById(Long.parseLong(session.get("usuario.id")));
		
	}
}
